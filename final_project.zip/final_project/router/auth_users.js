const express = require('express');
const jwt = require('jsonwebtoken');
const books = require("./booksdb.js");
const regd_users = express.Router();

let users = [];

const booksArray = Object.values(books); // Convert the books object into an array

const isValid = (username) => {
    return users.some(user => user.username === username);
}

const authenticatedUser = (username, password) => {
    return users.some(user => user.username === username && user.password === password);
}

// only registered users can login
regd_users.post("/login", (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        return res.status(208).json({ message: "Invalid credentials" });
    }

    if (authenticatedUser(username, password)) {
        const accessToken = jwt.sign({ data: password }, 'access', { expiresIn: 60 * 60 });
        req.session.authorization = { accessToken, username };
        return res.status(200).send("User successfully logged in");
    } else {
        return res.status(208).json({ message: "Invalid Username and Password" });
    }
});

regd_users.put("/auth/review/:isbn", (req, res) => {
    const isbn = req.params.isbn;
    const review = req.body.review;

    console.log("Received PUT request to update review for ISBN:", isbn);
    console.log("Received review:", review);

    // Access book by serial number (ISBN)
    const book = books[isbn];

    if (book) {
        // Update the review of the book
        book.reviews = review;
        return res.status(200).json({ "review updated": review });
    } else {
        return res.status(404).json({ message: "Book not found" });
    }
});

regd_users.delete("/auth/review/:isbn", (req, res) => {
    const isbn = req.params.isbn;
    const book = books[isbn];

    if (book) {
        // Check if the book has reviews
        if (book.reviews) {
            // Delete the reviews property
            delete book.reviews;
            return res.status(200).json({ "reviews deleted": true });
        } else {
            return res.status(404).json({ message: "Reviews not found for this book" });
        }
    } else {
        return res.status(404).json({ message: "Book not found" });
    }
});




module.exports.authenticated = regd_users;
module.exports.isValid = isValid;
module.exports.users = users;
