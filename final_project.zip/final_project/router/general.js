// Import required modules
const express = require('express');
const books = require("./booksdb.js");
const public_users = express.Router();

// Convert the books object into an array
const booksArray = Object.values(books);

// Route to get all books (Using async callback function)
public_users.get('/', async (req, res) => {
    try {
        const allBooks = await getAllBooksAsync();
        res.status(200).json(allBooks);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch books" });
    }
});

// Helper function to get all books (Using async callback function)
function getAllBooksAsync() {
    return new Promise((resolve, reject) => {
        process.nextTick(() => {
            resolve(booksArray);
        });
    });
}

// Route to search by ISBN (Using Promises)
public_users.get('/isbn/:isbn', (req, res) => {
    const isbn = req.params.isbn;
    searchByISBN(isbn)
        .then(book => {
            if (book) {
                res.status(200).json(book);
            } else {
                res.status(404).json({ message: "Book not found" });
            }
        })
        .catch(error => {
            res.status(500).json({ error: "Failed to search by ISBN" });
        });
});

// Helper function to search by ISBN (Using Promises)
function searchByISBN(isbn) {
    return new Promise((resolve, reject) => {
        const book = books[isbn];
        resolve(book);
    });
}

// Route to search by Author (Using async/await)
public_users.get('/author/:author', async (req, res) => {
    const author = req.params.author;
    try {
        const booksByAuthor = await searchByAuthorAsync(author);
        if (booksByAuthor.length > 0) {
            res.status(200).json(booksByAuthor);
        } else {
            res.status(404).json({ message: "Books by this author not found" });
        }
    } catch (error) {
        res.status(500).json({ error: "Failed to search by author" });
    }
});

// Helper function to search by Author (Using async/await)
function searchByAuthorAsync(author) {
    return new Promise((resolve, reject) => {
        process.nextTick(() => {
            const booksByAuthor = booksArray.filter(book => book.author === author);
            resolve(booksByAuthor);
        });
    });
}

// Route to search by Title (Using Promises)
public_users.get('/title/:title', (req, res) => {
    const title = req.params.title;
    searchByTitle(title)
        .then(booksWithTitle => {
            if (booksWithTitle.length > 0) {
                res.status(200).json(booksWithTitle);
            } else {
                res.status(404).json({ message: "Books with this title not found" });
            }
        })
        .catch(error => {
            res.status(500).json({ error: "Failed to search by title" });
        });
});

// Helper function to search by Title (Using Promises)
function searchByTitle(title) {
    return new Promise((resolve, reject) => {
        process.nextTick(() => {
            const booksWithTitle = booksArray.filter(book => book.title === title);
            resolve(booksWithTitle);
        });
    });
}

// Get book review
public_users.get('/review/:isbn', function (req, res) {
    const isbn = req.params.isbn;
    const book = books[isbn]; // Access book by ISBN (serial number)

    // Check if the book exists and if it has a review
    if (book && book.reviews && Object.keys(book.reviews).length > 0) {
        res.status(200).json({ review: book.reviews });
    } else {
        return res.status(404).json({ message: "Review not found" });
    }
});

module.exports.general = public_users;
